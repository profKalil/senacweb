<?php

include 'config.php';

$sql = "SELECT * FROM livros ORDER BY id DESC";
$res = $conn->query($sql);
    echo "<table class=\"margem\" border=\"1\">";
    echo "<tr><th>Autor</th>";
    echo "<th>Título</th></tr>";

while ($aux = mysqli_fetch_assoc($res)) {
   echo "<tr><td>".$aux["autor"]."</td>";
   echo "<td>".$aux["titulo"]."</td></tr>";
}

    echo "</table>";

    mysqli_close($conn);
?>