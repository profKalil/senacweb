<?php

include 'livro.php';
include 'biblioteca.php';
include 'config.php';

    $autor = $_POST["autor"];  
    $titulo = $_POST["titulo"];

    $biblioteca = new Biblioteca();

    $biblioteca->cadastrarLivro("$autor", "$titulo");
    
    //$biblioteca->exibirLivros();
    
?>
