<style>
    .margem {
        margin-top: 20px;
        margin-left: 50px;
    }
</style>
<?php

class Biblioteca {
    private $livros = [];

    public function cadastrarLivro($autor, $titulo) {
        $livro = new Livro($autor, $titulo);
        $this->livros[] = $livro;
        include "config.php";
        $sql = "INSERT INTO livros (autor, titulo) 
            VALUES ('{$autor}', '{$titulo}' )";
            $res = $conn->query($sql);
            mysqli_close($conn);

            header("Location: index.php");
    }

    public function exibirLivros() {
        echo "<div class=\"margem\">";
        echo "<h4>Livros Cadastrados:</h4>";
        echo "<table border=\"1\">";
        echo "<th>Autor";
        echo "<th>Titulo";
        foreach ($this->livros as $livro) {
            echo "<tr><td>". $livro->getAutor() ."</td>".
            "<td>" . $livro->getTitulo() . "</td></tr>";
        }
        echo "</table>";
        //echo "<\div>";
    }
}

?>