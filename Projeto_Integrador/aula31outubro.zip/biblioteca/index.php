<style>
    .margem-btn {
        margin-top: 20px;
        margin-left: 95px;
    }
    .margem {
        margin-top: 20px;
        margin-left: 50px;
    }

    .margem-campo {
        margin-top: 5px;
    }
</style>
<div class="margem" style="width: 230px;">
    <form action="action_forms.php" method="post">
        <fieldset>
            <legend>Cadastrar Livro</legend>
            <div class="margem-campo">
                <label for="autor">Autor:</label><br>
                <input type="text" id="titulo" name="autor"><br>
            </div>
            <div class="margem-campo">
                <label for="titulo">Título:</label><br>
                <input type="text" id="titulo" name="titulo"><br>
            </div>
            <input class="margem-btn" type="submit" value="Cadastrar">
        </fieldset>
    </form>
</div>

<?php
    include 'banco.php';
?>