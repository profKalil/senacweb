<!DOCTYPE html>
<html>
<body>

<h1>CADASTRAR<h1>
<form action="salvar.php" method="POST">
<label>Nome: </label>
<input type="text" name="nome">
<label>Email: </label>
<input type="email" name="email">
<label>Data: </label>
<input type="date" name="data">
<button type="submit">OK</button>



</body>
</html>


