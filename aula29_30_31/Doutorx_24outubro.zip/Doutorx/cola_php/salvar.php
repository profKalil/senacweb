<?php
    
    include("config.php");

    $nome = $_POST["nome"];
    $email = $_POST["email"];
    $data = $_POST["data"];

    $sql = "INSERT INTO cadastro (nome, email, data) VALUES ('{$nome}', '{$email}', '{$data}')";
    $res = $conn-> query($sql);

    mysqli_close($conn);

    header("Location: index.php");
    exit();
  
?>
