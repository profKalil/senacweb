<!DOCTYPE html>
<html>

<ul>
 <li><a href="index.php">HOME</li>
 <li><a href="cadastrar.php">Cadastrar</li>
<ul>

<?php
    include ("config.php");
    $sql = "SELECT * FROM cadastro";

    $res = mysqli_query($conn, $sql);

    echo "<table border=1>";

    while ($registro = mysqli_fetch_array($res)) {
        $id = $registro['id'];
        $nome = $registro['nome'];
        $email = $registro['email'];
        $data = $registro['data'];
        echo "<tr>";
        echo "<td>".$id."</td>";
	echo "<td>".$nome."</td>";
	echo "<td>".$email."</td>";
	echo "<td>".$data."</td>";
    }
   mysqli_close($conn);
   echo "</table>";
  
?>

</html>

