<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Doutor X - template Index PHP</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
</head>

<body>

  <!-- ======= HEADER E NAVIBAR ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex ">
      <a href="index.php" class="logo me-auto nav-bar" style="padding: 0px; margin:0px; color: rgb(0,125,198);"><img
          src="img/logon.jpg" alt="logo principal do site doutor x"></a>
      <nav id="navbar" class="navbar ">
        <ul>
          <li><a class="nav-link" href="#hero">INÍCIO</a></li>
          <li><a class="nav-link scrollto" href="#sobre">SOBRE</a></li>
          <li><a class="nav-link scrollto" href="#servicos">SERVIÇOS</a></li>
          <li><a class="nav-link scrollto" href="#departamentos">DEPARTAMENTOS</a></li>
          <li><a class="nav-link scrollto" href="#equipe">EQUIPE</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>
      <a href="#agenda" class="btn btn-padrao">
        Consultar
      </a>
    </div>
  </header>
