<!-- ======= SEÇÃO SERVIÇOS ======= -->
<section id="services" class="services services">
    <div class="container">

        <div class="section-title">
            <h2>SERVIÇOS</h2>
            <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint
                consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat
                sit
                in iste officiis commodi quidem hic quas.</p>
        </div>

        <div class="row">
            <div class="col-lg-4 col-md-6 icon-box">

                <a href="">
                    <div class="icon"><i class="fas fa-heartbeat"></i>
                        <img src="img/departments-1.jpg" alt="foto de itens médicos" width="100%;">
                    </div>
                    <h4 class="title"><br> Farmácia
                </a></h4>
                <p class="description">Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint
                    occaecati cupiditate non provident</p>
            </div>
            <div class="col-lg-4 col-md-6 icon-box">
                <a href="">
                    <div class="icon"><i class="fas fa-heartbeat"></i>
                        <img src="img/departments-2.jpg" alt="" width="100%">
                    </div>
                    <h4 class="title"><br> Titulo
                </a></h4>
                <p class="description">Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint
                    occaecati cupiditate non provident</p>
            </div>
            <div class="col-lg-4 col-md-6 icon-box">
                <a href="">
                    <div class="icon"><i class="fas fa-heartbeat"></i></div>
                    <h4 class="title"><br> Titulo
                </a></h4>
                <p class="description">Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint
                    occaecati cupiditate non provident</p>
            </div>
            <div class="col-lg-4 col-md-6 icon-box">
                <a href="">
                    <div class="icon"><i class="fas fa-heartbeat"></i></div>
                    <h4 class="title"><br> Titulo
                </a></h4>
                <p class="description">Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint
                    occaecati cupiditate non provident</p>
            </div>
            <div class="col-lg-4 col-md-6 icon-box">
                <a href="">
                    <div class="icon"><i class="fas fa-heartbeat"></i></div>
                    <h4 class="title"><br> Titulo
                </a></h4>
                <p class="description">Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint
                    occaecati cupiditate non provident</p>
            </div>
            <div class="col-lg-4 col-md-6 icon-box">
                <a href="">
                    <div class="icon"><i class="fas fa-heartbeat"></i></div>
                    <h4 class="title"><br> Titulo
                </a></h4>
                <p class="description">Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint
                    occaecati cupiditate non provident</p>
            </div>
        </div>

    </div><span id="agenda"></span>
</section>