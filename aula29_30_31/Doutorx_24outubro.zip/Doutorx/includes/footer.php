<!-- ======= Footer ======= -->
<footer id="footer">
    <div class="footer-top">
        <div class="container">
            <div class="row">

                <div class="col-lg-3 col-md-6">
                    <div class="footer-info">
                        <h3>Doutor-X</h3>
                        <p>
                            Rua dos doutores <br>
                            Araranguá 5555, Brasil<br><br>
                            <strong>Telefone:</strong> 48 555 5555<br>
                            <strong>Email:</strong> doutorx@doutorx.com<br>
                        </p>

                    </div>
                </div>

                <div class="col-lg-2 col-md-6 footer-links">
                    <h4>Nossos links</h4>
                    <ul>
                        <li><i class="bx bx-chevron-right"></i> <a href="#home">Início</a></li>
                        <li><i class="bx bx-chevron-right"></i> <a href="#sobre">Sobre nós</a></li>
                        <li><i class="bx bx-chevron-right"></i> <a href="#servicos">Serviços</a></li>
                        <li><i class="bx bx-chevron-right"></i> <a href="#departamentos">Departamentos</a></li>
                        <li><i class="bx bx-chevron-right"></i> <a href="#equipe">Equipe</a></li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6 footer-links">
                    <h4>Utilidades</h4>
                    <ul>
                        <li><i class="bx bx-chevron-right"></i> <a href="#">Planos de Saúde</a></li>
                        <li><i class="bx bx-chevron-right"></i> <a href="#">Hospitais conveniados</a></li>
                        <li><i class="bx bx-chevron-right"></i> <a href="#">Imprensa</a></li>
                        <li><i class="bx bx-chevron-right"></i> <a href="#">Vagas de Emprego</a></li>
                        <li><i class="bx bx-chevron-right"></i> <a href="#">Termos e Condições</a></li>
                    </ul>
                </div>

                <div class="col-lg-4 col-md-6 footer-newsletter">
                    <h4>Assine nosso Newsletter</h4>
                    <p>Receba notícias sobre a Doutor-X em seu e-mail, gratuitamente</p>
                    <form action="forms/contact.php" method="post">
                        <input type="email" name="email" required><input type="submit" value="Enviar"
                            style="color: #FFF; background-color: rgb(0,125,198);">
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="copyright">
            &copy; Copyright <strong><span>Doutor-X</span></strong>. All Rights Reserved
        </div>
        <div class="credits">
            Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
        </div>
    </div>
</footer><!-- End Footer -->

<script src="bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="js/main.js"></script>
</body>

</html>