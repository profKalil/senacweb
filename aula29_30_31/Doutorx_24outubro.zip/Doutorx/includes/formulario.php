<form action="forms/agenda.php" method="post">
    <div class="row">
        <div class="col-md-4 form-group mt-3 mb-3">
            <input type="text" name="login" class="form-control" id="name" placeholder="Login" required>
        </div>
        <div class="col-md-4 form-group mt-3 mb-3">
            <input type="password" name="senha" class="form-control" id="name" placeholder="Senha" required>
        </div>
        <div class="col-md-4 form-group mt-3 md-3">
            <input type="text" name="nome" class="form-control" id="name" placeholder="Your Name" required>
        </div>
        <div class="col-md-4 form-group mt-3 mt-md-0">
            <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
        </div>
        <div class="col-md-4 form-group mt-3 mt-md-0">
            <input type="tel" class="form-control" name="fone" id="phone" placeholder="Your Phone" required>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4 form-group mt-3">
            <input type="date" name="date" class="form-control datepicker" id="date" placeholder="Appointment Date"
                required>
        </div>
        <div class="col-md-4 form-group mt-3">
            <select name="departamento" id="department" class="form-select">
                <option value="">Select Department</option>
                <option value="Department 1">Department 1</option>
                <option value="Department 2">Department 2</option>
                <option value="Department 3">Department 3</option>
            </select>
        </div>
        <div class="col-md-4 form-group mt-3">
            <select name="doctor" id="doctor" class="form-select">
                <option value="">Select Doctor</option>
                <option value="Doctor 1">Doctor 1</option>
                <option value="Doctor 2">Doctor 2</option>
                <option value="Doctor 3">Doctor 3</option>
            </select>
        </div>
    </div>

    <div class="form-group mt-3">
        <textarea class="form-control" name="message" rows="5" placeholder="Message (Optional)"></textarea>
    </div>

    <div class="text-center"><button style="margin-top:15px;" class="btn btn-padrao" type="submit">Marque uma
            consulta</button></div>
</form>