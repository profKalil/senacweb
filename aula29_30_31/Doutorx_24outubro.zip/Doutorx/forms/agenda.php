<?php

include("config.php");

$sql = "SELECT * FROM usuarios";
$res = $conn->query($sql);

$login = $_POST["login"];
$senha = $_POST["senha"];

while ($aux = mysqli_fetch_assoc($res)) {
    if (($login == $aux["login"]) && ($senha == $aux["senha"])) {
        $valida = true;
    } else {
        $valida = false;
    }
}

if ($valida == true) {
    $login = $_POST["login"];
    $senha = $_POST["senha"];
    $nome = $_POST["nome"];
    $email = $_POST["email"];
    $fone = $_POST["fone"];
    $date_ = $_POST["date"];
    $departamento = $_POST["departamento"];
    $doctor = $_POST["doctor"];
    $message_ = $_POST["message"];

    $sql = "INSERT INTO cadastro (nome, email, fone, date_, departamento, doctor, message_) 
            VALUES ('{$nome}', '{$email}', '{$fone}', '{$date_}', '{$departamento}', '{$doctor}', '{$message_}' )";
    $res = $conn->query($sql);

    echo "<script>alert('Dados inseridos com sucesso!');</script>";

} else {
    echo "<script>alert('Verifique seus dados');</script>";
}

mysqli_close($conn);

//header("Location: ../index.php");
exit();

?>