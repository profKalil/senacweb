<!-- ======= Hero Section ======= -->
  <div class="container centralizar">
	  <section id="hero">
		<div id="heroCarousel" data-bs-interval="3000" class="carousel slide carousel-fade" data-bs-ride="carousel">
			<div class="carousel-inner" >
			<div class="carousel-item active" style="background-image: url(img/slide/slide-1.jpg)"> </div>
			<div class="carousel-item" style="background-image: url(img/slide/slide-2.jpg)"> </div>
			<div class="carousel-item" style="background-image: url(img/slide/slide-3.jpg)"> </div>
		  </div>

		  <a class="carousel-control-prev" href="#heroCarousel" data-bs-slide="prev">
			<span class="carousel-control-prev-icon bi bi-chevron-left" aria-hidden="true"></span>
		  </a>

		  <a class="carousel-control-next" href="#heroCarousel" data-bs-slide="next">
			<span class="carousel-control-next-icon bi bi-chevron-right" aria-hidden="true"></span>
		  </a>
		</div>
	  </section>
  </div>
  

  <main id="main">