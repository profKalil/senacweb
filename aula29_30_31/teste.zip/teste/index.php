<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_SESSION['authenticated']) && $_SESSION['authenticated'] === true) {
        // Aqui você processaria o envio do formulário para o banco de dados
        $atividade_escolhida = $_POST['atividade'];
        // Realize a lógica de inserção no banco de dados aqui
        
        // Limpar a sessão após o envio bem-sucedido
        unset($_SESSION['authenticated']);
        
        echo "Atividade enviada com sucesso!";
    } else {
        echo "Erro de autenticação. Tente novamente.";
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulário de Atividade</title>
</head>
<body>
    <form action="index.php" method="post" target="_blank" onsubmit="openAuthModal();">
        <label for="atividade">Escolha uma atividade:</label>
        <select name="atividade" id="atividade">
            <!-- Opções da atividade vêm da sua lógica de negócios -->
            <option value="atividade1">Atividade 1</option>
            <option value="atividade2">Atividade 2</option>
            <option value="atividade3">Atividade 3</option>
        </select>
        <br>

        <!-- Adicione outros campos do formulário, se necessário -->

        <br>
        <input type="submit" value="Enviar">
    </form>
</body>
</html>

<script>
function openAuthModal() {
    window.open('authenticate.php', 'authentication', 'width=400,height=300');
    return false; // Impede o envio normal do formulário
}
</script>