<?php
session_start();

// Verificar se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verificar as credenciais (substitua essas verificações com seu próprio mecanismo de autenticação)
    $username = 'usuario';  // Substitua com o nome de usuário desejado
    $password = 'senha123';  // Substitua com a senha desejada

    if ($_POST['username'] === $username && $_POST['password'] === $password) {
        // Autenticação bem-sucedida, configurar a sessão
        $_SESSION['authenticated'] = true;

        // Redirecionar de volta ao script principal (index.php)
        header('Location: index.php');
        exit();
    } else {
        // Credenciais inválidas, exibir mensagem de erro
        echo "Credenciais inválidas. Tente novamente.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Autenticação</title>
</head>
<body>
    <h2>Por favor, faça login</h2>
    <form action="authenticate.php" method="post">
        <label for="username">Usuário:</label>
        <input type="text" name="username" id="username" required>
        <br>

        <label for="password">Senha:</label>
        <input type="password" name="password" id="password" required>
        <br>

        <input type="submit" value="Login">
    </form>
</body>
</html>
