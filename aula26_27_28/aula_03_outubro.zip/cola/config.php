<?php

define('HOST', 'aqui vai o nome do host + .railway.app');
define('USER', 'root');
define('PASS', 'aqui vai a senha ');
define('BASE', 'railway');
define('PORT', 8035);

$conn = new MySQLi(HOST,USER,PASS,BASE,PORT);

if ($conn->connect_error) {
    die("Falha na conexão com o banco de dados: " . $conn->connect_error);
}


?>
